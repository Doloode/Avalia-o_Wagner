// Utilitários de Limpeza e Sanitização (Segurança contra XSS)
const sanitize = {
  xss: (str) => str.replace(/[&<>"']/g, (m) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[m]),
  onlyNumbers: (str) => str.replace(/\D/g, ''),
  onlyLetters: (str) => str.replace(/[^a-zA-Zà-úÀ-Ú\s]/g, '')
};

// Elementos Dinâmicos
const tipoPessoaSelect = document.getElementById('tipoPessoa');
const labelNome = document.getElementById('labelNome');
const labelDocumento = document.getElementById('labelDocumento');
const inputDocumento = document.getElementById('documento');
const docErrorMsg = document.getElementById('documentoError');
const groupNascimento = document.getElementById('groupNascimento');
const inputNascimento = document.getElementById('dataNascimento');

// Controle de Exibição Dinâmica entre PF e PJ
tipoPessoaSelect.addEventListener('change', (e) => {
  const isPF = e.target.value === 'PF';

  // Limpa campos para evitar contaminação de dados
  inputDocumento.value = '';
  inputNascimento.value = '';
  toggleError('documento', true);
  toggleError('dataNascimento', true);

  if (isPF) {
    labelNome.textContent = 'Nome Completo *';
    labelDocumento.textContent = 'CPF *';
    inputDocumento.placeholder = '000.000.000-00';
    inputDocumento.maxLength = 14;
    docErrorMsg.textContent = 'Insira um número válido de CPF (11 dígitos).';
    groupNascimento.classList.remove('hidden'); // Exibe Data de Nascimento
  } else {
    labelNome.textContent = 'Razão Social / Nome Fantasia *';
    labelDocumento.textContent = 'CNPJ *';
    inputDocumento.placeholder = '00.000.000/0001-00';
    inputDocumento.maxLength = 18;
    docErrorMsg.textContent = 'Insira um número válido de CNPJ (14 dígitos).';
    groupNascimento.classList.add('hidden'); // Oculta Data de Nascimento
  }
});

// Máscaras de Digitação em Tempo Real
document.getElementById('telefone').addEventListener('input', (e) => {
  let x = sanitize.onlyNumbers(e.target.value);
  if (x.length > 11) x = x.slice(0, 11);
  if (x.length > 10) e.target.value = `(${x.slice(0, 2)}) ${x.slice(2, 7)}-${x.slice(7)}`;
  else if (x.length > 6) e.target.value = `(${x.slice(0, 2)}) ${x.slice(2, 6)}-${x.slice(6)}`;
  else if (x.length > 2) e.target.value = `(${x.slice(0, 2)}) ${x.slice(2)}`;
  else if (x.length > 0) e.target.value = `(${x}`;
});

document.getElementById('nome').addEventListener('input', (e) => {
  e.target.value = sanitize.onlyLetters(e.target.value);
});

inputDocumento.addEventListener('input', (e) => {
  let v = sanitize.onlyNumbers(e.target.value);
  const isPF = tipoPessoaSelect.value === 'PF';

  if (isPF) {
    if (v.length > 11) v = v.slice(0, 11);
    v = v.replace(/(\d{3})(\d)/, '$1.$2')
         .replace(/(\d{3})(\d)/, '$1.$2')
         .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  } else {
    if (v.length > 14) v = v.slice(0, 14);
    v = v.replace(/^(\d{2})(\d)/, '$1.$2')
         .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
         .replace(/\.(\d{3})(\d)/, '.$1/$2')
         .replace(/(\d{4})(\d)/, '$1-$2');
  }
  e.target.value = v;
});

document.getElementById('preco').addEventListener('input', (e) => {
  let value = sanitize.onlyNumbers(e.target.value);
  if (!value) { e.target.value = ''; return; }
  value = (parseFloat(value) / 100).toFixed(2);
  e.target.value = value.replace('.', ',').replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
});

document.getElementById('sku').addEventListener('input', (e) => {
  e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
});

// Funções de Validação de Regras de Negócio
const validate = {
  nome: (value) => {
    const clean = value.trim();
    return clean.length >= 3;
  },
  email: (value) => /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value.trim()),
  telefone: (value) => {
    const nums = sanitize.onlyNumbers(value);
    return nums.length === 10 || nums.length === 11;
  },
  documento: (value, tipo) => {
    const nums = sanitize.onlyNumbers(value);
    return tipo === 'PF' ? nums.length === 11 : nums.length === 14;
  },
  dataNascimento: (value, tipo) => {
    // Se for Pessoa Jurídica, ignora a validação
    if (tipo === 'PJ') return true;
    if (!value) return false;

    const dataInformada = new Date(value);
    const hoje = new Date();
    
    // Valida maioridade (Mínimo 18 anos)
    const dataLimite18Anos = new Date(hoje.getFullYear() - 18, hoje.getMonth(), hoje.getDate());
    return dataInformada <= dataLimite18Anos;
  },
  preco: (value) => {
    const rawValue = value.replace(/\./g, '').replace(',', '.');
    return !isNaN(parseFloat(rawValue)) && parseFloat(rawValue) > 0;
  },
  sku: (value) => /^[A-Z0-9-]{4,10}$/.test(value.trim())
};

// Gerenciamento dos estados visuais de erro
function toggleError(fieldId, isValid) {
  const field = document.getElementById(fieldId);
  const errorMsg = document.getElementById(`${fieldId}Error`);
  if (field && errorMsg) {
    if (!isValid) {
      field.classList.add('error');
      errorMsg.classList.add('active');
    } else {
      field.classList.remove('error');
      errorMsg.classList.remove('active');
    }
  }
  return isValid;
}

// Submit e Envio Limpo
document.getElementById('cadastroForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const tipo = tipoPessoaSelect.value;

  const isNomeValid = toggleError('nome', validate.nome(document.getElementById('nome').value));
  const isEmailValid = toggleError('email', validate.email(document.getElementById('email').value));
  const isTelefoneValid = toggleError('telefone', validate.telefone(document.getElementById('telefone').value));
  const isDocumentoValid = toggleError('documento', validate.documento(inputDocumento.value, tipo));
  const isNascimentoValid = toggleError('dataNascimento', validate.dataNascimento(inputNascimento.value, tipo));
  const isPrecoValid = toggleError('preco', validate.preco(document.getElementById('preco').value));
  const isSkuValid = toggleError('sku', validate.sku(document.getElementById('sku').value));

  const isFormValid = isNomeValid && isEmailValid && isTelefoneValid && isDocumentoValid && isNascimentoValid && isPrecoValid && isSkuValid;

  if (isFormValid) {
    // Cria o objeto de envio
    const payloadSeguro = {
      tipoPessoa: tipo,
      nome: sanitize.xss(document.getElementById('nome').value.trim()),
      email: sanitize.xss(document.getElementById('email').value.trim()),
      telefone: sanitize.onlyNumbers(document.getElementById('telefone').value),
      documento: sanitize.onlyNumbers(inputDocumento.value),
      preco: parseFloat(document.getElementById('preco').value.replace(/\./g, '').replace(',', '.')),
      sku: sanitize.xss(document.getElementById('sku').value.trim())
    };

    // Inclui a data de nascimento no payload APENAS se for Pessoa Física
    if (tipo === 'PF') {
      payloadSeguro.dataNascimento = inputNascimento.value;
    }

    console.log('Payload seguro pronto para o backend:', payloadSeguro);

    // Feedback de Sucesso
    const alert = document.getElementById('successAlert');
    alert.style.display = 'block';
    setTimeout(() => { alert.style.display = 'none'; }, 5000);

    this.reset();
    // Restaura interface padrão (PF)
    tipoPessoaSelect.dispatchEvent(new Event('change'));
  }
});