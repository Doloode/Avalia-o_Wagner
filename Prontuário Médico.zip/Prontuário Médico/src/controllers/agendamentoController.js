const PrecificacaoService = require('../services/precificacaoService');

class AgendamentoController {
    static criarAgendamento(req, res) {
        try {
            const { nome, cpf, email, especialidade, valorEnviadoPeloFront } = req.body;

            // Validação de dados obrigatórios
            if (!nome || !cpf || !email || !especialidade) {
                return res.status(400).json({ erro: "Dados incompletos para a solicitação." });
            }

            // INTEGRIDADE: O preço é definido estritamente pelo servidor
            const valorProcessado = PrecificacaoService.calcularValorReal(especialidade, valorEnviadoPeloFront);

            return res.status(200).json({
                sucesso: true,
                mensagem: "Agendamento realizado com sucesso!",
                detalhes: {
                    paciente: nome,
                    especialidade: especialidade,
                    valorProcessado: valorProcessado
                }
            });

        } catch (error) {
            // CONFIDENCIALIDADE: Não expõe o erro real/stack-trace nem credenciais do sistema na resposta
            console.error("Erro interno no servidor:", error);
            
            return res.status(500).json({
                erro: "Erro interno no servidor ao processar o agendamento. Nenhuma informação sensível foi exposta."
            });
        }
    }
}

module.exports = AgendamentoController;