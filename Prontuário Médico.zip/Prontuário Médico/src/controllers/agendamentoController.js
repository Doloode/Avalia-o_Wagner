const PrecificacaoService = require('../services/precificacaoService');

class AgendamentoController {
    static criarAgendamento(req, res) {
        try {
            const { nome, cpf, email, especialidade, nascimento, convenio, horario, consentimento, valorEnviadoPeloFront } = req.body;

            if (!nome || !cpf || !email || !especialidade || !nascimento || !convenio || !horario) {
                return res.status(400).json({ erro: "Dados incompletos para a solicitação." });
            }

            // CONFIDENCIALIDADE / LGPD: sem consentimento do titular, não processa
            if (!consentimento) {
                return res.status(400).json({ erro: "É necessário aceitar o Termo de Consentimento (LGPD) para agendar." });
            }

            const valorProcessado = PrecificacaoService.calcularValorReal(especialidade, valorEnviadoPeloFront);

            return res.status(200).json({
                sucesso: true,
                mensagem: "Agendamento realizado com sucesso!",
                detalhes: { paciente: nome, especialidade, valorProcessado }
            });

        } catch (error) {
            console.error("Erro interno no servidor:", error);
            return res.status(500).json({
                erro: "Erro interno no servidor ao processar o agendamento. Nenhuma informação sensível foi exposta."
            });
        }
    }
}

module.exports = AgendamentoController;