require('dotenv').config();
const express = require('express');
const path = require('path');
const appointmentLimiter = require('./middlewares/rateLimiter');
const AgendamentoController = require('./controllers/agendamentoController');

const app = express();
app.use(express.json());

// Serve os arquivos estáticos do Front-end
app.use(express.static(path.join(__dirname, 'views')));

// DISPONIBILIDADE: Rate limiting aplicado na rota de agendamento
app.post('/api/agendamento', appointmentLimiter, AgendamentoController.criarAgendamento);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});