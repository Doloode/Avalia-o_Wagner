document.addEventListener('DOMContentLoaded', () => {
    const cpfInput = document.getElementById('cpf');
    const telInput = document.getElementById('telefone');
    const form = document.getElementById('appointmentForm');
    const feedback = document.getElementById('mensagemFeedback');
    const modal = document.getElementById('modalLgpd');

    document.getElementById('linkTermos').addEventListener('click', (e) => {
        e.preventDefault();
        modal.classList.remove('hidden');
    });

    document.getElementById('fecharModal').addEventListener('click', () => {
        modal.classList.add('hidden');
    });

    cpfInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 11) value = value.slice(0, 11);
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
        e.target.value = value;
    });

    telInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 11) value = value.slice(0, 11);
        value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
        value = value.replace(/(\d{5})(\d)/, '$1-$2');
        e.target.value = value;
    });

    function mostrarFeedback(texto, tipo) {
        feedback.textContent = texto;
        feedback.className = `feedback ${tipo}`;
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        feedback.className = 'feedback';

        const payload = {
            nome: document.getElementById('nome').value,
            nascimento: document.getElementById('nascimento').value,
            cpf: cpfInput.value,
            email: document.getElementById('email').value,
            telefone: telInput.value,
            especialidade: document.getElementById('especialidade').value,
            convenio: document.getElementById('convenio').value,
            data: document.getElementById('data').value,
            horario: document.getElementById('horario').value,
            observacoes: document.getElementById('observacoes').value,
            consentimento: document.getElementById('consentimento').checked,
            valorEnviadoPeloFront: 1.00
        };

        try {
            const response = await fetch('/api/agendamento', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            if (response.ok) {
                mostrarFeedback(`${result.mensagem} Valor: R$ ${result.detalhes.valorProcessado}`, 'sucesso');
                form.reset();
            } else {
                mostrarFeedback(result.erro, 'erro');
            }
        } catch (error) {
            mostrarFeedback('Falha na comunicação com o servidor.', 'erro');
        }
    });
});