document.addEventListener('DOMContentLoaded', () => {
    const cpfInput = document.getElementById('cpf');
    const telInput = document.getElementById('telefone');
    const form = document.getElementById('appointmentForm');

    // Máscara de Entrada: CPF (000.000.000-00)
    cpfInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 11) value = value.slice(0, 11);
        
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
        
        e.target.value = value;
    });

    // Máscara de Entrada: Telefone ((00) 00000-0000)
    telInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 11) value = value.slice(0, 11);
        
        value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
        value = value.replace(/(\d{5})(\d)/, '$1-$2');
        
        e.target.value = value;
    });

    // Envio dos dados para o Back-End com teste de integridade
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const payload = {
            nome: document.getElementById('nome').value,
            cpf: cpfInput.value,
            email: document.getElementById('email').value,
            telefone: telInput.value,
            especialidade: document.getElementById('especialidade').value,
            data: document.getElementById('data').value,
            observacoes: document.getElementById('observacoes').value,
            // Simulação: Enviando um valor alterado propositalmente pelo Front para testar Integridade no servidor
            valorEnviadoPeloFront: 1.00 
        };

        try {
            const response = await fetch('/api/agendamento', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            if (response.ok) {
                alert(`Sucesso! ${result.mensagem}\nValor Garantido pelo Servidor: R$ ${result.detalhes.valorProcessado}`);
            } else {
                alert(`Erro: ${result.erro}`);
            }
        } catch (error) {
            alert('Falha na comunicação com o servidor.');
        }
    });
});