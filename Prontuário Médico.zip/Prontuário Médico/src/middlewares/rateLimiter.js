const rateLimit = require('express-rate-limit');

// DISPONIBILIDADE: Proteção contra ataques de negação de serviço e sobrecarga
const appointmentLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // Janela de 15 minutos
    max: 10, // Limite de 10 requisições por IP a cada 15 minutos
    message: { 
        status: 429, 
        erro: "Muitas solicitações detectadas. Tente novamente mais tarde para garantir a disponibilidade do sistema." 
    }
});

module.exports = appointmentLimiter;