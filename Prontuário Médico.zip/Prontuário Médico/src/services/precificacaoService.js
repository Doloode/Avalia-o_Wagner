// INTEGRIDADE: Tabela oficial de preços no servidor (fonte da verdade)
const TABELA_PRECOS = {
    'geral': 150.00,
    'cardiologia': 250.00,
    'dermatologia': 200.00
};

class PrecificacaoService {
    static calcularValorReal(especialidade, valorEnviadoPeloFront) {
        const especialidadeChave = especialidade ? especialidade.toLowerCase() : 'geral';
        const valorReal = TABELA_PRECOS[especialidadeChave] || 150.00;

        // Alerta no console caso o Front-end envie um valor divergente/adulterado
        if (valorEnviadoPeloFront && valorEnviadoPeloFront !== valorReal) {
            console.warn(`[ALERTA DE SEGURANÇA] Tentativa de alteração de preço detectada! Front enviou: R$ ${valorEnviadoPeloFront}, mas o Servidor processará: R$ ${valorReal}`);
        }

        return valorReal;
    }
}

module.exports = PrecificacaoService;