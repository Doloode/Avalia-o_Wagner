require('dotenv').config();
const express = require('express');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(express.json());

// -----------------------------------------------------------------------------
// 1. DISPONIBILIDADE (Tríade CID)
// Controle de carga para evitar ataques de Negação de Serviço (DoS) e sobrecarga
// -----------------------------------------------------------------------------
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // Janela de 15 minutos
    max: 10, // Limite de 10 requisições por IP por janela
    message: { status: 429, erro: "Muitas solicitações detectadas. Tente novamente mais tarde." }
});

// Aplica o Rate Limit na rota de agendamento
app.use('/api/agendamento', limiter);

// -----------------------------------------------------------------------------
// Tabela de Preços no Servidor (Regra de Negócio)
// -----------------------------------------------------------------------------
const TABELA_PRECOS = {
    'geral': 150.00,
    'cardiologia': 250.00,
    'dermatologia': 200.00
};

// -----------------------------------------------------------------------------
// 2. INTEGRIDADE E CONFIDENCIALIDADE (Tríade CID)
// -----------------------------------------------------------------------------
app.post('/api/agendamento', (req, res) => {
    try {
        const { nome, cpf, email, especialidade, valorEnviadoPeloFront } = req.body;

        // Validação basica de presença de dados obrigatórios
        if (!nome || !cpf || !email || !especialidade) {
            return res.status(400).json({ erro: "Dados incompletos para a solicitação." });
        }

        // --- INTEGRIDADE ---
        // O Back-end NUNCA confia no preço enviado pelo Front-end.
        // O valor real é buscado diretamente da fonte oficial do servidor.
        const valorReal = TABELA_PRECOS[especialidade.toLowerCase()] || 150.00;

        if (valorEnviadoPeloFront && valorEnviadoPeloFront !== valorReal) {
            console.warn(`[ALERTA DE SEGURANÇA] Tentativa de alteração de valor detectada! Front enviado: ${valorEnviadoPeloFront}, Real: ${valorReal}`);
        }

        // Resposta processada com integridade
        return res.status(200).json({
            sucesso: true,
            mensagem: "Agendamento realizado com sucesso!",
            detalhes: {
                paciente: nome,
                especialidade: especialidade,
                valorProcessado: valorReal // Valor garantido pelo Back-end
            }
        });

    } catch (error) {
        // --- CONFIDENCIALIDADE ---
        // Tratamento de erro seguro: Não expõe detalhes do código, chaves de API ou stack-trace
        console.error("Erro interno do servidor:", error); // Log interno apenas
        return res.status(500).json({
            erro: "Ocorreu um erro interno ao processar seu agendamento. Tente novamente."
        });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor de Segurança rodando na porta ${PORT}`);
});