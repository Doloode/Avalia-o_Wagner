# Projeto Segurança da Informação — Agendamento de Consultas / Prontuário Médico

Projeto acadêmico focado em aplicar práticas de Segurança da Informação no Front-end e a Tríade CID no Back-end.

## Checklist implementado
**Front-end:** tipagem de inputs, campos obrigatórios, limite de caracteres, máscaras de entrada (CPF/telefone).
**Back-end (Tríade CID):** confidencialidade (erros sem stack-trace), integridade (preço recalculado no servidor), disponibilidade (rate limiting).

## Como rodar
\`\`\`
npm install
npm start
\`\`\`
Acesse http://localhost:3000