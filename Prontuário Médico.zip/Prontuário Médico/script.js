document.addEventListener('DOMContentLoaded', () => {
    const cpfInput = document.getElementById('cpf');
    const telInput = document.getElementById('telefone');
    const form = document.getElementById('appointmentForm');

    // Máscara de Entrada: CPF (000.000.000-00)
    cpfInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, ''); // Remove não dígitos
        if (value.length > 11) value = value.slice(0, 11);
        
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
        
        e.target.value = value;
    });

    // Máscara de Entrada: Telefone ((00) 00000-0000)
    telInput.addEventListener('input', (e) => {
        let value = e.target.value.replace(/\D/g, ''); // Remove não dígitos
        if (value.length > 11) value = value.slice(0, 11);
        
        value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
        value = value.replace(/(\d{5})(\d)/, '$1-$2');
        
        e.target.value = value;
    });

    // Validação de envio
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Formulário validado com sucesso no Front-end! Pronto para envio ao Back-end.');
    });
});